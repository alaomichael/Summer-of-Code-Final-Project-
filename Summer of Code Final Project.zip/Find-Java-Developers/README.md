# Find-Java-Developers
Andela Project For Intermediate Level Android Developers
# Libraries used
* Retrofit for Http connection
* Picasso For Image rendering
* Glide for Image caching

# Contributors
* Owolabi Tobiloba

# App Description
** An android app that fetches a list of Java developers residing in Lagos.
